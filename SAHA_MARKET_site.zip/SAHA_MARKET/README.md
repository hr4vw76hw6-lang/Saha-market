# SAHA MARKET — demo

Static responsive showcase, no payments, no database, no account selling or live pricing.

## Deploy on Vercel
1. Upload this project to a GitHub repository.
2. Go to https://vercel.com and sign in with GitHub.
3. Choose **Add New → Project** and import the repository.
4. Framework preset: **Other**. Build command and output directory can be left empty for static HTML.
5. Click **Deploy**. Vercel will provide a public HTTPS URL.

To connect a Telegram Mini App, configure its URL with BotFather after deployment. Replace Telegram links and sample listings with your own support link and moderated content.
